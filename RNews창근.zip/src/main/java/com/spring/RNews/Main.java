package com.spring.RNews;
import org.springframework.context.support.GenericXmlApplicationContext;
public class Main {
    public static void main(String [] args){
        String url = "mongoContext.xml";
        GenericXmlApplicationContext ctx = new GenericXmlApplicationContext(url);
        MongoDAO dao = ctx.getBean("mongoDAO", MongoDAO.class);
        if(dao == null){
            System.out.println("NULL!!!!");
        }
        else{
            
            System.out.println("NOT NULL :)");
//            dao.insertTestVO();
            dao.findPersonByName("���ݰԸ��� 200000 ȣ��");
//            dao.insertPersonMassive();
//            dao.updatePerson();
//            dao.deletePerson();
//            dao.deletePersonByName("�輮��");
            
        }
        
    }
    
}